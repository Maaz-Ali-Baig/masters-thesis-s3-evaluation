$ aws --endpoint-url http://localhost:19000 s3api head-object --bucket s3c-rustfs101-la-1009131301-main --key c05/copy.bin --query Metadata.z --output text
