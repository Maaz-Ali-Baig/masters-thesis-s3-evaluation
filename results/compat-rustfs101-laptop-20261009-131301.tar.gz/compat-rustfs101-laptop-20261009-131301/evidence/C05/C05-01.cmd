$ aws --endpoint-url http://localhost:19000 s3api copy-object --bucket s3c-rustfs101-la-1009131301-main --key c05/copy.bin --copy-source s3c-rustfs101-la-1009131301-main/fixture/rand1m.bin
