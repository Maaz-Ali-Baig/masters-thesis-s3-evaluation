$ aws --endpoint-url http://localhost:19000 s3api put-bucket-cors --bucket s3c-rustfs101-la-1009131301-main --cors-configuration file:///tmp/rf101-compat/data/cors.json
