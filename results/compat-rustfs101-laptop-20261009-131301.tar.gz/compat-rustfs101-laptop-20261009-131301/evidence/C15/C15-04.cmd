$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://evil.example -H Access-Control-Request-Method: GET http://localhost:19000/s3c-rustfs101-la-1009131301-main/fixture/rand1m.bin
