$ aws --endpoint-url http://localhost:19000 s3api delete-object-tagging --bucket s3c-rustfs101-la-1009131301-main --key c09/tag.txt
