$ aws --endpoint-url http://localhost:19000 s3api put-bucket-policy --bucket s3c-rustfs101-la-1009131301-main --policy file:///tmp/rf101-compat/data/policy.json
