$ aws --endpoint-url http://localhost:19000 s3api get-bucket-policy --bucket s3c-rustfs101-la-1009131301-main --query Policy --output text
