$ aws --endpoint-url http://localhost:19000 s3 cp /tmp/rf101-compat/data/rand1m.bin s3://s3c-rustfs101-la-1009131301-main/c20/cp.bin
