$ aws --endpoint-url http://localhost:19000 s3api put-bucket-versioning --bucket s3c-rustfs101-la-1009131301-ver --versioning-configuration Status=Enabled
