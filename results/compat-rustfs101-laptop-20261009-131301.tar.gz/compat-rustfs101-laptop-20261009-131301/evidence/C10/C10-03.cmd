$ aws --endpoint-url http://localhost:19000 s3api get-bucket-versioning --bucket s3c-rustfs101-la-1009131301-ver --query Status --output text
