$ aws --endpoint-url http://localhost:19000 s3api list-object-versions --bucket s3c-rustfs101-la-1009131301-ver --prefix c10/v.txt --query length(Versions) --output text
