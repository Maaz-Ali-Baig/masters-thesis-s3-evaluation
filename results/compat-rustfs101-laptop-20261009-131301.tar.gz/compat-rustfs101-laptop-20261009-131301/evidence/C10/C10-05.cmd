$ aws --endpoint-url http://localhost:19000 s3api put-object --bucket s3c-rustfs101-la-1009131301-ver --key c10/v.txt --body /tmp/rf101-compat/data/v2.txt
