$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009131301-ver --key c10/v.txt --query DeleteMarker --output text
