$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-ver --key c10/v.txt /tmp/rf101-compat/evidence/C10/hidden.txt
