$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009131301-ver --key c10/v.txt --version-id 76f14810-301f-4101-a9a9-05699d99cbba
