$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-main --key c02/rand1m.bin /tmp/rf101-compat/evidence/C02/get.bin
