$ aws --endpoint-url http://localhost:19000 s3api put-bucket-lifecycle-configuration --bucket s3c-rustfs101-la-1009131301-main --lifecycle-configuration file:///tmp/rf101-compat/data/lifecycle.json
