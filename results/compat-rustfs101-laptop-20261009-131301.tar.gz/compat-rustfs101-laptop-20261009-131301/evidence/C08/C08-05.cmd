$ aws --endpoint-url http://localhost:19000 s3api list-multipart-uploads --bucket s3c-rustfs101-la-1009131301-main --query Uploads[].UploadId --output text
