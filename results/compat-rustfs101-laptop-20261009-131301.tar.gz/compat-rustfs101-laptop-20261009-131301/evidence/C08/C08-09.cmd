$ aws --endpoint-url http://localhost:19000 s3api create-multipart-upload --bucket s3c-rustfs101-la-1009131301-main --key c08/aborted.bin --query UploadId --output text
