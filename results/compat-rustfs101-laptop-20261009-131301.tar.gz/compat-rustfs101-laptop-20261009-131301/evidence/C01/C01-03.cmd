$ aws --endpoint-url http://localhost:19000 s3api list-buckets --query Buckets[].Name --output text
