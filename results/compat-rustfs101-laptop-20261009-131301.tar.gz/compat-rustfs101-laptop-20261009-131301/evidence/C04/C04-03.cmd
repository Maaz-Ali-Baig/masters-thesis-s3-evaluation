$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-main --key fixture/rand1m.bin --range bytes=100- /tmp/rf101-compat/evidence/C04/r3.bin
