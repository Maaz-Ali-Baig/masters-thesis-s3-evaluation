$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-main --key c07/a.txt /tmp/rf101-compat/evidence/C07/gone.bin
