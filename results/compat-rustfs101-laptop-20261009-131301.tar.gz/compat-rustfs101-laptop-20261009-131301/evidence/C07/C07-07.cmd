$ aws --endpoint-url http://localhost:19000 s3api delete-objects --bucket s3c-rustfs101-la-1009131301-main --delete {"Objects":[{"Key":"c07/b.txt"},{"Key":"c07/c.txt"}],"Quiet":false}
