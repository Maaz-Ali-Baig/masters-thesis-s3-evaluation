$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009131301-lock --key c17/locked.txt --version-id aff3efb4-60b9-4802-947e-75933d381162
