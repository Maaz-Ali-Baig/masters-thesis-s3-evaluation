$ aws --endpoint-url http://localhost:19000 s3api put-object --bucket s3c-rustfs101-la-1009131301-main --key fixture/rand1m.bin --body /tmp/rf101-compat/data/rand1m.bin
