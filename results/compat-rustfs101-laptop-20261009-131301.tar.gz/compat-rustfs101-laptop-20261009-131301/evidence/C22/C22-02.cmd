$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-no-such-bucket --key x /tmp/rf101-compat/evidence/C22/x.bin
