$ aws --endpoint-url http://localhost:19000 s3api create-bucket --bucket Bad_Name_s3c-rustfs101-la-1009131301
