$ aws --endpoint-url http://localhost:19000 s3api put-object-acl --bucket s3c-rustfs101-la-1009131301-main --key c19/acl.txt --acl private
