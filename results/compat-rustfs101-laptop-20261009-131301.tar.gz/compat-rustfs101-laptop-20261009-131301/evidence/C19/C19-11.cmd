$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:19000/s3c-rustfs101-la-1009131301-main/c19/acl.txt
