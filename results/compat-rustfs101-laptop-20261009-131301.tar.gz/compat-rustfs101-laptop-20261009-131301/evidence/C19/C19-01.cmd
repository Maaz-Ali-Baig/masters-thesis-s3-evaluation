$ aws --endpoint-url http://localhost:19000 s3api get-bucket-acl --bucket s3c-rustfs101-la-1009131301-main --query length(Grants) --output text
