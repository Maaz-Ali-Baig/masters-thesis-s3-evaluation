$ aws --endpoint-url http://localhost:19000 s3api get-object-acl --bucket s3c-rustfs101-la-1009131301-main --key c19/acl.txt --query Grants[].Grantee.URI --output text
