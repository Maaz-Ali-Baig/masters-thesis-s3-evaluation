$ aws --endpoint-url http://localhost:19000 s3api list-objects-v2 --bucket s3c-rustfs101-la-1009131301-main --prefix c21/ --query length(Contents) --output text
