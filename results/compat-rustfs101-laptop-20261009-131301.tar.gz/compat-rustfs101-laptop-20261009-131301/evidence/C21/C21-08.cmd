$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-main --key c21/pct%20x.txt /tmp/rf101-compat/evidence/C21/k4.bin
