$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009131301-main --key c21/a+b=c&d.txt /tmp/rf101-compat/evidence/C21/k3.bin
