$ aws --endpoint-url http://localhost:19000 s3api delete-bucket-encryption --bucket s3c-rustfs101-la-1009233952-main
