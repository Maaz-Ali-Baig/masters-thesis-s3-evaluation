$ aws --endpoint-url http://localhost:19000 s3api head-object --bucket s3c-rustfs101-la-1009233952-main --key c18/sse.bin --query ServerSideEncryption --output text
