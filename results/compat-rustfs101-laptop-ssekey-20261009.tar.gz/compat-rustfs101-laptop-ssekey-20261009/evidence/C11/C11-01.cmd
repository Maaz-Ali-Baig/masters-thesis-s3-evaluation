$ aws --endpoint-url http://localhost:19000 s3api head-object --bucket s3c-rustfs101-la-1009233952-main --key fixture/rand1m.bin --query ETag --output text
