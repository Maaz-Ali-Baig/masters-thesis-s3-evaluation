$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009233952-main --key fixture/rand1m.bin --range bytes=100- /tmp/rf101-full/evidence/C04/r3.bin
