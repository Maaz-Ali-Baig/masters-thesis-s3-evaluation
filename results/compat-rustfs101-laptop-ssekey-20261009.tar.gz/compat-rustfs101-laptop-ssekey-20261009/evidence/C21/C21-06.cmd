$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009233952-main --key c21/a+b=c&d.txt /tmp/rf101-full/evidence/C21/k3.bin
