$ aws --endpoint-url http://localhost:19000 s3api put-bucket-cors --bucket s3c-rustfs101-la-1009233952-main --cors-configuration file:///tmp/rf101-full/data/cors.json
