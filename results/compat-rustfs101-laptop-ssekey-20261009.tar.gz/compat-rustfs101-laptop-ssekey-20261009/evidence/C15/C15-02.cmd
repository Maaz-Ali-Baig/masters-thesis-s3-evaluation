$ aws --endpoint-url http://localhost:19000 s3api get-bucket-cors --bucket s3c-rustfs101-la-1009233952-main --query CORSRules[0].AllowedOrigins[0] --output text
