$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://example.org -H Access-Control-Request-Method: GET http://localhost:19000/s3c-rustfs101-la-1009233952-main/fixture/rand1m.bin
