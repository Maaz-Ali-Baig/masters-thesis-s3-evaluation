$ aws --endpoint-url http://localhost:19000 s3api delete-objects --bucket s3c-rustfs101-la-1009233952-main --delete {"Objects":[{"Key":"c07/b.txt"},{"Key":"c07/c.txt"}],"Quiet":false}
