$ aws --endpoint-url http://localhost:19000 s3 cp s3://s3c-rustfs101-la-1009233952-main/c20/cp.bin /tmp/rf101-full/evidence/C20/cp.bin
