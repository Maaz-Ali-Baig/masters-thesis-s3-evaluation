$ aws --endpoint-url http://localhost:19000 s3 presign s3://s3c-rustfs101-la-1009233952-main/c13/p.txt --expires-in 2
