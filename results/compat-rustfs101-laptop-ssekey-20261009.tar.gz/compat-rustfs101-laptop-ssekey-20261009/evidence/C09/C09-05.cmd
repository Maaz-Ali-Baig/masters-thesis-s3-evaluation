$ aws --endpoint-url http://localhost:19000 s3api get-object-tagging --bucket s3c-rustfs101-la-1009233952-main --key c09/tag2.txt --query length(TagSet) --output text
