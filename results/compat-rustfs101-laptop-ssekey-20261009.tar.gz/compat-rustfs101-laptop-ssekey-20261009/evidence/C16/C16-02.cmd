$ aws --endpoint-url http://localhost:19000 s3api get-bucket-lifecycle-configuration --bucket s3c-rustfs101-la-1009233952-main --query Rules[0].ID --output text
