$ aws --endpoint-url http://localhost:19000 s3api delete-bucket-lifecycle --bucket s3c-rustfs101-la-1009233952-main
