$ aws --endpoint-url http://localhost:19000 s3api list-objects --bucket s3c-rustfs101-la-1009233952-main --prefix c06/ --query length(Contents) --output text
