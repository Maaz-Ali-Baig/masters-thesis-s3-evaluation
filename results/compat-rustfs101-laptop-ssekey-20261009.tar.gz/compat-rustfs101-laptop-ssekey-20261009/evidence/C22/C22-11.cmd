$ aws --endpoint-url http://localhost:19000 s3api delete-bucket --bucket s3c-rustfs101-la-1009233952-never-created
