$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009233952-lock --key c17/locked.txt --version-id 69a6084c-a1cd-4ebe-8cdc-823ce208d8c0
