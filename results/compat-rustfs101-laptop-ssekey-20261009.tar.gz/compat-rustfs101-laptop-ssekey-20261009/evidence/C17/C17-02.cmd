$ aws --endpoint-url http://localhost:19000 s3api get-object-lock-configuration --bucket s3c-rustfs101-la-1009233952-lock --query ObjectLockConfiguration.ObjectLockEnabled --output text
