$ aws --endpoint-url http://localhost:19000 s3api put-object --bucket s3c-rustfs101-la-1009233952-ver --key c10/v.txt --body /tmp/rf101-full/data/v1.txt
