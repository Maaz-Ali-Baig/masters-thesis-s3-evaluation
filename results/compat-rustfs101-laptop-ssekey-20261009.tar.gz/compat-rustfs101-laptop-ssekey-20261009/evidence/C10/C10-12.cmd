$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009233952-ver --key c10/v.txt --version-id e7341f68-cb5b-4a91-9eca-ee34981b4922
