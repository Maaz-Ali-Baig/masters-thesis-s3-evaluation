$ aws --endpoint-url http://localhost:19000 s3api delete-object --bucket s3c-rustfs101-la-1009233952-ver --key c10/v.txt --query DeleteMarker --output text
