$ aws --endpoint-url http://localhost:19000 s3api list-object-versions --bucket s3c-rustfs101-la-1009233952-ver --prefix c10/v.txt --query Versions[?IsLatest==`false`].VersionId | [0] --output text
