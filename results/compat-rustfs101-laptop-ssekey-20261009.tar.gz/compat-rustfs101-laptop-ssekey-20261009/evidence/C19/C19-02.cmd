$ aws --endpoint-url http://localhost:19000 s3api put-object --bucket s3c-rustfs101-la-1009233952-main --key c19-flat.txt --body /tmp/rf101-full/data/small.txt
