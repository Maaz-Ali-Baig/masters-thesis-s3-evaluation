$ aws --endpoint-url http://localhost:19000 s3api get-bucket-acl --bucket s3c-rustfs101-la-1009233952-main --query length(Grants) --output text
