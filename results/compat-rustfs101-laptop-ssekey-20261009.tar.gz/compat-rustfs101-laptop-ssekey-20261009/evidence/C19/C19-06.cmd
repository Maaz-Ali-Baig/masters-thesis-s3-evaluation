$ aws --endpoint-url http://localhost:19000 s3api put-object-acl --bucket s3c-rustfs101-la-1009233952-main --key c19-flat.txt --acl private
