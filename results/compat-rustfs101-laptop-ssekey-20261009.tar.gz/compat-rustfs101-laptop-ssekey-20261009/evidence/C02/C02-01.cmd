$ aws --endpoint-url http://localhost:19000 s3api put-object --bucket s3c-rustfs101-la-1009233952-main --key c02/rand1m.bin --body /tmp/rf101-full/data/rand1m.bin --query ETag --output text
