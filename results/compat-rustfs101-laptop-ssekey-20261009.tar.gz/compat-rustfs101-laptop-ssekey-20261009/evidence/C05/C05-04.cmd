$ aws --endpoint-url http://localhost:19000 s3api head-object --bucket s3c-rustfs101-la-1009233952-main --key c05/copy.bin --query Metadata.z --output text
