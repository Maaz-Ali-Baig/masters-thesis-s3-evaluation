$ aws --endpoint-url http://localhost:19000 s3api get-object --bucket s3c-rustfs101-la-1009233952-main --key c05/copy.bin /tmp/rf101-full/evidence/C05/copy.bin
