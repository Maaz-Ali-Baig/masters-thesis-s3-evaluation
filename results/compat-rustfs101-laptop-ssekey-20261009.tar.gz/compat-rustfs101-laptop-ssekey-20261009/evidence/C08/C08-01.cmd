$ aws --endpoint-url http://localhost:19000 s3api create-multipart-upload --bucket s3c-rustfs101-la-1009233952-main --key c08/mp.bin --query UploadId --output text
