$ aws --endpoint-url http://localhost:19000 s3api put-bucket-policy --bucket s3c-rustfs101-la-1009233952-main --policy file:///tmp/rf101-full/data/policy.json
