$ aws --endpoint-url http://localhost:8333 s3api get-bucket-policy --bucket s3c-seaweedfs-0930205945-main --query Policy --output text
