$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:8333/s3c-seaweedfs-0930205945-main/fixture/rand1m.bin
