$ aws --endpoint-url http://localhost:8333 s3api head-object --bucket s3c-seaweedfs-0930205945-main --key c02/rand1m.bin --query ContentLength --output text
