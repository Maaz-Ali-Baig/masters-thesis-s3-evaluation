$ aws --endpoint-url http://localhost:8333 s3api head-object --bucket s3c-seaweedfs-0930205945-main --key c08/mp.bin --query ETag --output text
