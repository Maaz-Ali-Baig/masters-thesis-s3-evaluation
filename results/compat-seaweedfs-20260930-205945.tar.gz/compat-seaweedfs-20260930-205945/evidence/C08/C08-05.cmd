$ aws --endpoint-url http://localhost:8333 s3api list-multipart-uploads --bucket s3c-seaweedfs-0930205945-main --query Uploads[].UploadId --output text
