$ aws --endpoint-url http://localhost:8333 s3api create-multipart-upload --bucket s3c-seaweedfs-0930205945-main --key c08/small-parts.bin --query UploadId --output text
