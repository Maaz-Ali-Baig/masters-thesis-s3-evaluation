$ aws --endpoint-url http://localhost:8333 s3api head-bucket --bucket s3c-seaweedfs-0930205945-c01
