$ aws --endpoint-url http://localhost:8333 s3api list-buckets --query Buckets[].Name --output text
