$ aws --endpoint-url http://localhost:8333 s3api head-object --bucket s3c-seaweedfs-0930205945-main --key fixture/rand1m.bin --query ETag --output text
