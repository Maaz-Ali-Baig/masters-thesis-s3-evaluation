$ aws --endpoint-url http://localhost:8333 s3api get-object-tagging --bucket s3c-seaweedfs-0930205945-main --key c09/tag.txt --query length(TagSet) --output text
