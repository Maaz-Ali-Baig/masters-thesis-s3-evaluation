$ aws --endpoint-url http://localhost:8333 s3api delete-object --bucket s3c-seaweedfs-0930205945-ver --key c10/v.txt --query DeleteMarker --output text
