$ aws --endpoint-url http://localhost:8333 s3api put-bucket-versioning --bucket s3c-seaweedfs-0930205945-ver --versioning-configuration Status=Enabled
