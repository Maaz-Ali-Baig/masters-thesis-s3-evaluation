$ aws --endpoint-url http://localhost:8333 s3api list-object-versions --bucket s3c-seaweedfs-0930205945-ver --prefix c10/v.txt --query length(Versions) --output text
