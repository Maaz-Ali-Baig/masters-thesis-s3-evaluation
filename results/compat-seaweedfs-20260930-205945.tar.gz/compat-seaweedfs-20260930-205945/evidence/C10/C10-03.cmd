$ aws --endpoint-url http://localhost:8333 s3api get-bucket-versioning --bucket s3c-seaweedfs-0930205945-ver --query Status --output text
