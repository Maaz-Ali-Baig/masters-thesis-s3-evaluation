$ aws --endpoint-url http://localhost:8333 s3api list-objects --bucket s3c-seaweedfs-0930205945-main --prefix c06/ --query length(Contents) --output text
