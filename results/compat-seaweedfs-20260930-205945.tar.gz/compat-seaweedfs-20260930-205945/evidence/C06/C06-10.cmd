$ aws --endpoint-url http://localhost:8333 s3api list-objects-v2 --bucket s3c-seaweedfs-0930205945-main --prefix c06/ --start-after c06/a/2.txt --query length(Contents) --output text
