$ aws --endpoint-url http://localhost:8333 s3api list-objects-v2 --bucket s3c-seaweedfs-0930205945-main --prefix c06/ --delimiter / --query [length(CommonPrefixes),length(Contents)] --output text
