$ aws --endpoint-url http://localhost:8333 s3api list-objects-v2 --bucket s3c-seaweedfs-0930205945-c22 --query Contents[].Key --output text
