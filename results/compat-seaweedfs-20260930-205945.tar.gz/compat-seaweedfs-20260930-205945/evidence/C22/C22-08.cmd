$ aws --endpoint-url http://localhost:8333 s3api delete-bucket --bucket s3c-seaweedfs-0930205945-c22
