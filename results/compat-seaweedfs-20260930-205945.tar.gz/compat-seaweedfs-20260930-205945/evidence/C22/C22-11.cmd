$ aws --endpoint-url http://localhost:8333 s3api create-bucket --bucket Bad_Name_s3c-seaweedfs-0930205945
