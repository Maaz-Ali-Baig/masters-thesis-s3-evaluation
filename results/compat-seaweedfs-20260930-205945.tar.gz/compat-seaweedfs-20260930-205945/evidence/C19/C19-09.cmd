$ aws --endpoint-url http://localhost:8333 s3api put-object-acl --bucket s3c-seaweedfs-0930205945-main --key c19/acl.txt --acl public-read
