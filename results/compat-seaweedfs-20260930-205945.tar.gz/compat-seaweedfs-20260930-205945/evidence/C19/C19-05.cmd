$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:8333/s3c-seaweedfs-0930205945-main/c19-flat.txt
