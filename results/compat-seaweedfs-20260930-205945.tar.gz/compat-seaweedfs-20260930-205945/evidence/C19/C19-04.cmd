$ aws --endpoint-url http://localhost:8333 s3api get-object-acl --bucket s3c-seaweedfs-0930205945-main --key c19-flat.txt --query Grants[].Grantee.URI --output text
