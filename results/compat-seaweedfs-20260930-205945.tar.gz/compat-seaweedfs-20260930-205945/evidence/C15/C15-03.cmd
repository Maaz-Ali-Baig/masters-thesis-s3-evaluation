$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://example.org -H Access-Control-Request-Method: GET http://localhost:8333/s3c-seaweedfs-0930205945-main/fixture/rand1m.bin
