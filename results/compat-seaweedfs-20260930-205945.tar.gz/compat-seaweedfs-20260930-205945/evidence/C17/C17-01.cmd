$ aws --endpoint-url http://localhost:8333 s3api create-bucket --bucket s3c-seaweedfs-0930205945-lock --object-lock-enabled-for-bucket
