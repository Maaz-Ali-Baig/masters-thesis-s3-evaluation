$ aws --endpoint-url http://localhost:8333 s3api delete-object --bucket s3c-seaweedfs-0930205945-lock --key c17/locked.txt --version-id 6725d16be75e16dfd35775eb91b56228 --bypass-governance-retention
