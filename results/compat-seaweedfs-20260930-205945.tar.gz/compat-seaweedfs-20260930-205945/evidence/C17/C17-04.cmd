$ aws --endpoint-url http://localhost:8333 s3api head-object --bucket s3c-seaweedfs-0930205945-lock --key c17/locked.txt --query ObjectLockMode --output text
