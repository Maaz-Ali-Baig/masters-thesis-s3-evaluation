$ aws --endpoint-url http://localhost:8333 s3api get-object-lock-configuration --bucket s3c-seaweedfs-0930205945-lock --query ObjectLockConfiguration.ObjectLockEnabled --output text
