$ aws --endpoint-url http://localhost:8333 s3api delete-objects --bucket s3c-seaweedfs-0930205945-main --delete {"Objects":[{"Key":"c07/b.txt"},{"Key":"c07/c.txt"}],"Quiet":false}
