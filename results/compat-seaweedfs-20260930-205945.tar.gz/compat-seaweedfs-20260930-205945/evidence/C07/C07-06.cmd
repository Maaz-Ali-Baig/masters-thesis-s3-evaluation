$ aws --endpoint-url http://localhost:8333 s3api delete-object --bucket s3c-seaweedfs-0930205945-main --key c07/never-existed.txt
