$ aws --endpoint-url http://localhost:8333 s3 presign s3://s3c-seaweedfs-0930205945-main/c13/p.txt --expires-in 60
