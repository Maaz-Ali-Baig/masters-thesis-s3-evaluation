$ aws --endpoint-url http://localhost:8333 s3api copy-object --bucket s3c-seaweedfs-0930205945-main --key c05/copy.bin --copy-source s3c-seaweedfs-0930205945-main/fixture/rand1m.bin
