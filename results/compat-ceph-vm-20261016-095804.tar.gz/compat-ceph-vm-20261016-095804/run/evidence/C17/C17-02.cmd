$ aws --endpoint-url http://localhost:80 s3api get-object-lock-configuration --bucket s3c-ceph-vm-1016095808-lock --query ObjectLockConfiguration.ObjectLockEnabled --output text
