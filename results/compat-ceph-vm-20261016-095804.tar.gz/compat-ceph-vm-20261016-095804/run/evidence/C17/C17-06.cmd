$ aws --endpoint-url http://localhost:80 s3api delete-object --bucket s3c-ceph-vm-1016095808-lock --key c17/locked.txt --version-id D9MvDF2HLmBlyT.KtsnQvDsn5zJqNyj --bypass-governance-retention
