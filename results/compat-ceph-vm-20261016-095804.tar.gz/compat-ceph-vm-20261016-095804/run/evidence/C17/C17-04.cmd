$ aws --endpoint-url http://localhost:80 s3api head-object --bucket s3c-ceph-vm-1016095808-lock --key c17/locked.txt --query ObjectLockMode --output text
