$ aws --endpoint-url http://localhost:80 s3api put-object --bucket s3c-ceph-vm-1016095808-main --key fixture/rand1m.bin --body /root/compat-ceph-vm-20261016-095804/run/data/rand1m.bin
