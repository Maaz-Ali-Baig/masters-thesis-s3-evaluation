$ aws --endpoint-url http://localhost:80 s3api get-bucket-policy --bucket s3c-ceph-vm-1016095808-main --query Policy --output text
