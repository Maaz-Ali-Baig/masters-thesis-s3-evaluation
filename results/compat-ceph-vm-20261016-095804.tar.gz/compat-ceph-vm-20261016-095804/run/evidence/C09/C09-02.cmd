$ aws --endpoint-url http://localhost:80 s3api put-object-tagging --bucket s3c-ceph-vm-1016095808-main --key c09/tag.txt --tagging {"TagSet":[{"Key":"env","Value":"test"},{"Key":"k2","Value":"v2"}]}
