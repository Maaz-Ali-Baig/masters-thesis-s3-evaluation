$ aws --endpoint-url http://localhost:80 s3api get-object-tagging --bucket s3c-ceph-vm-1016095808-main --key c09/tag.txt --query length(TagSet) --output text
