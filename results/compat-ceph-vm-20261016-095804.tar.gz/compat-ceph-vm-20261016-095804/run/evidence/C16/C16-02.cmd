$ aws --endpoint-url http://localhost:80 s3api get-bucket-lifecycle-configuration --bucket s3c-ceph-vm-1016095808-main --query Rules[0].ID --output text
