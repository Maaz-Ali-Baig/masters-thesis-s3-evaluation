$ aws --endpoint-url http://localhost:80 s3api put-object-acl --bucket s3c-ceph-vm-1016095808-main --key c19/acl.txt --acl private
