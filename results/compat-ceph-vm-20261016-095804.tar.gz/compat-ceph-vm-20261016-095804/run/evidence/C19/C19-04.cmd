$ aws --endpoint-url http://localhost:80 s3api get-object-acl --bucket s3c-ceph-vm-1016095808-main --key c19-flat.txt --query Grants[].Grantee.URI --output text
