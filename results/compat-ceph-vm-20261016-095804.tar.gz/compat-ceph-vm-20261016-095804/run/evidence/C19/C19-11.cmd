$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:80/s3c-ceph-vm-1016095808-main/c19/acl.txt
