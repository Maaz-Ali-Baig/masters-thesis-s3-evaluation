$ aws --endpoint-url http://localhost:80 s3api delete-objects --bucket s3c-ceph-vm-1016095808-main --delete {"Objects":[{"Key":"c07/b.txt"},{"Key":"c07/c.txt"}],"Quiet":false}
