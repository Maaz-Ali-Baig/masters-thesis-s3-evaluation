$ aws --endpoint-url http://localhost:80 s3api delete-object --bucket s3c-ceph-vm-1016095808-main --key c07/never-existed.txt
