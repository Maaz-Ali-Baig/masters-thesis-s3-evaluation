$ aws --endpoint-url http://localhost:80 s3api head-object --bucket s3c-ceph-vm-1016095808-main --key c05/copy.bin --query Metadata.z --output text
