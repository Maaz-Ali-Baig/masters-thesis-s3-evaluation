$ aws --endpoint-url http://localhost:80 s3api copy-object --bucket s3c-ceph-vm-1016095808-main --key c05/copy.bin --copy-source s3c-ceph-vm-1016095808-main/fixture/rand1m.bin
