$ aws --endpoint-url http://localhost:80 s3api list-objects --bucket s3c-ceph-vm-1016095808-main --prefix c06/ --query length(Contents) --output text
