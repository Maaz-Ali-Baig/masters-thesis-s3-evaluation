$ aws --endpoint-url http://localhost:80 s3api delete-object --bucket s3c-ceph-vm-1016095808-ver --key c10/v.txt --query DeleteMarker --output text
