$ aws --endpoint-url http://localhost:80 s3api put-bucket-versioning --bucket s3c-ceph-vm-1016095808-ver --versioning-configuration Status=Enabled
