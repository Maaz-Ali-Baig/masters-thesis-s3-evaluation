$ aws --endpoint-url http://localhost:80 s3api delete-object --bucket s3c-ceph-vm-1016095808-ver --key c10/v.txt --version-id 6qjIW70Q2c1.xmZGsRBtMOSd2yV9sbE
