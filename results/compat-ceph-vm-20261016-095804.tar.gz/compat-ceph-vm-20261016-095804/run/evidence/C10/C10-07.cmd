$ aws --endpoint-url http://localhost:80 s3api list-object-versions --bucket s3c-ceph-vm-1016095808-ver --prefix c10/v.txt --query Versions[?IsLatest==`false`].VersionId | [0] --output text
