$ aws --endpoint-url http://localhost:80 s3api get-bucket-versioning --bucket s3c-ceph-vm-1016095808-ver --query Status --output text
