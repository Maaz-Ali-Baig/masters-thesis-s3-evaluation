$ aws --endpoint-url http://localhost:80 s3api abort-multipart-upload --bucket s3c-ceph-vm-1016095808-main --key c08/aborted.bin --upload-id 2~h37pAAfnd0BjiadlLd9e3uPqhXM3h20
