$ aws --endpoint-url http://localhost:80 s3api abort-multipart-upload --bucket s3c-ceph-vm-1016095808-main --key c08/small-parts.bin --upload-id 2~9p70-eXcZzgBxxnKFkBufMJ6n42Kj_U
