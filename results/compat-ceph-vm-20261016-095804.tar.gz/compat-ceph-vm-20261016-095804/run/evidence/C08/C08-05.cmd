$ aws --endpoint-url http://localhost:80 s3api list-multipart-uploads --bucket s3c-ceph-vm-1016095808-main --query Uploads[].UploadId --output text
