$ aws --endpoint-url http://localhost:80 s3api list-parts --bucket s3c-ceph-vm-1016095808-main --key c08/mp.bin --upload-id 2~PJMmmVpqyb6TIk3yECwIhYt5N3qDsVH --query length(Parts) --output text
