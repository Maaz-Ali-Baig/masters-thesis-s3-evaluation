$ aws --endpoint-url http://localhost:80 s3api create-multipart-upload --bucket s3c-ceph-vm-1016095808-main --key c08/small-parts.bin --query UploadId --output text
