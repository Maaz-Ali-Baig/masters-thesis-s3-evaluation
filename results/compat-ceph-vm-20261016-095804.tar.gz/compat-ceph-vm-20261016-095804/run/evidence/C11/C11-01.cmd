$ aws --endpoint-url http://localhost:80 s3api head-object --bucket s3c-ceph-vm-1016095808-main --key fixture/rand1m.bin --query ETag --output text
