$ aws --endpoint-url http://localhost:80 s3 cp /root/compat-ceph-vm-20261016-095804/run/data/rand1m.bin s3://s3c-ceph-vm-1016095808-main/c20/cp.bin
