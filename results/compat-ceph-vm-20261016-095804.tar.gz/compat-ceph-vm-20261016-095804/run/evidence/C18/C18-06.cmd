$ aws --endpoint-url http://localhost:80 s3api delete-bucket-encryption --bucket s3c-ceph-vm-1016095808-main
