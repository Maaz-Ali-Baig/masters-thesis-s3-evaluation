$ aws --endpoint-url http://localhost:80 s3api head-object --bucket s3c-ceph-vm-1016095808-main --key c18/sse.bin --query ServerSideEncryption --output text
