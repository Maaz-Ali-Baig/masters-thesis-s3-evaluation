$ aws --endpoint-url http://localhost:80 s3 presign s3://s3c-ceph-vm-1016095808-main/c13/p.txt --expires-in 60
