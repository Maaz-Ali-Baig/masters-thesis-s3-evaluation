$ aws --endpoint-url http://localhost:80 s3api list-buckets --query Buckets[].Name --output text
