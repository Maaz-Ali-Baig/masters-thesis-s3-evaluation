$ aws --endpoint-url http://localhost:80 s3api head-bucket --bucket s3c-ceph-vm-1016095808-c01
