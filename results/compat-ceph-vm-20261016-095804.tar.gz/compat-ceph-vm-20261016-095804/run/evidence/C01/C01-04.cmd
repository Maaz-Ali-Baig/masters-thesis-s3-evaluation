$ aws --endpoint-url http://localhost:80 s3api delete-bucket --bucket s3c-ceph-vm-1016095808-c01
