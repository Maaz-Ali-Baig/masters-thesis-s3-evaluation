$ aws --endpoint-url http://localhost:80 s3api list-objects-v2 --bucket s3c-ceph-vm-1016095808-main --prefix c21/ --query length(Contents) --output text
