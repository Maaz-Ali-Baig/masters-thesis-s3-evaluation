$ aws --endpoint-url http://localhost:80 s3api get-object --bucket s3c-ceph-vm-1016095808-main --key c21/a+b=c&d.txt /root/compat-ceph-vm-20261016-095804/run/evidence/C21/k3.bin
