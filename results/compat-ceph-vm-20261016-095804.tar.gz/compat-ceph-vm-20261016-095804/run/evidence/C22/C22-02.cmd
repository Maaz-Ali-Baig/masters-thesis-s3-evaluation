$ aws --endpoint-url http://localhost:80 s3api get-object --bucket s3c-ceph-vm-1016095808-no-such-bucket --key x /root/compat-ceph-vm-20261016-095804/run/evidence/C22/x.bin
