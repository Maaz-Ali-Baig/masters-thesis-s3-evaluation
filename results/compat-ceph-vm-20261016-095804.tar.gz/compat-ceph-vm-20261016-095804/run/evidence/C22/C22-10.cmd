$ aws --endpoint-url http://localhost:80 s3api create-bucket --bucket Bad_Name_s3c-ceph-vm-1016095808
