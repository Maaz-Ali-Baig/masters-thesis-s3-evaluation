$ aws --endpoint-url http://localhost:80 s3api delete-object --bucket s3c-ceph-vm-1016095808-c22 --key sentinel.txt
