$ aws --endpoint-url http://localhost:80 s3api get-bucket-cors --bucket s3c-ceph-vm-1016095808-main --query CORSRules[0].AllowedOrigins[0] --output text
