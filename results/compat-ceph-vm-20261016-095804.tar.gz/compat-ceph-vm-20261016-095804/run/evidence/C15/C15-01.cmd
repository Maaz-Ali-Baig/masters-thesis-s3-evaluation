$ aws --endpoint-url http://localhost:80 s3api put-bucket-cors --bucket s3c-ceph-vm-1016095808-main --cors-configuration file:///root/compat-ceph-vm-20261016-095804/run/data/cors.json
