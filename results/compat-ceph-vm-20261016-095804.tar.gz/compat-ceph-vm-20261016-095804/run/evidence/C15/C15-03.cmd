$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://example.org -H Access-Control-Request-Method: GET http://localhost:80/s3c-ceph-vm-1016095808-main/fixture/rand1m.bin
