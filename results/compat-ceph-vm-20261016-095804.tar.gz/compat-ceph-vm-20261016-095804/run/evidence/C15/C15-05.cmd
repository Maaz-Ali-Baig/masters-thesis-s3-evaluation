$ aws --endpoint-url http://localhost:80 s3api delete-bucket-cors --bucket s3c-ceph-vm-1016095808-main
