$ aws --endpoint-url http://localhost:9000 s3api head-object --bucket s3c-rustfs-0930210446-main --key fixture/rand1m.bin --query ETag --output text
