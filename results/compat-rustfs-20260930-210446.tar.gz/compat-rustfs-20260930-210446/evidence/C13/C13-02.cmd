$ aws --endpoint-url http://localhost:9000 s3 presign s3://s3c-rustfs-0930210446-main/c13/p.txt --expires-in 60
