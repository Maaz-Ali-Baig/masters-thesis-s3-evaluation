$ aws --endpoint-url http://localhost:9000 s3api get-bucket-cors --bucket s3c-rustfs-0930210446-main
