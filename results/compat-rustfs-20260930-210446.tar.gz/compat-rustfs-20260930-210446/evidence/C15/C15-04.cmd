$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://evil.example -H Access-Control-Request-Method: GET http://localhost:9000/s3c-rustfs-0930210446-main/fixture/rand1m.bin
