$ aws --endpoint-url http://localhost:9000 s3api put-object-acl --bucket s3c-rustfs-0930210446-main --key c19-flat.txt --acl private
