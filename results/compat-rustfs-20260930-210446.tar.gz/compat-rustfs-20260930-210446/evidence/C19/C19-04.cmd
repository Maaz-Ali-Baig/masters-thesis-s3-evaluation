$ aws --endpoint-url http://localhost:9000 s3api get-object-acl --bucket s3c-rustfs-0930210446-main --key c19-flat.txt --query Grants[].Grantee.URI --output text
