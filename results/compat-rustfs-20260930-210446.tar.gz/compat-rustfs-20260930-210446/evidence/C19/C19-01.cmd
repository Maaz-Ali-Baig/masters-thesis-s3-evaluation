$ aws --endpoint-url http://localhost:9000 s3api get-bucket-acl --bucket s3c-rustfs-0930210446-main --query length(Grants) --output text
