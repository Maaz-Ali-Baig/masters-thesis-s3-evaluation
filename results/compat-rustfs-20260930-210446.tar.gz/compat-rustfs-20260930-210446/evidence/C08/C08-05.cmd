$ aws --endpoint-url http://localhost:9000 s3api list-multipart-uploads --bucket s3c-rustfs-0930210446-main --query Uploads[].UploadId --output text
