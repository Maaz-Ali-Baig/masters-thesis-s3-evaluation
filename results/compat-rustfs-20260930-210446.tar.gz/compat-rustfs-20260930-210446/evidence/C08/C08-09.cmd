$ aws --endpoint-url http://localhost:9000 s3api create-multipart-upload --bucket s3c-rustfs-0930210446-main --key c08/aborted.bin --query UploadId --output text
