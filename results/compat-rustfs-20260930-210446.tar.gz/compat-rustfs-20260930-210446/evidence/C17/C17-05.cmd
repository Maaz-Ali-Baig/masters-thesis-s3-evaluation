$ aws --endpoint-url http://localhost:9000 s3api delete-object --bucket s3c-rustfs-0930210446-lock --key c17/locked.txt --version-id bac21724-0d2e-48d3-a0db-4f37fb05961e
