$ aws --endpoint-url http://localhost:9000 s3api head-object --bucket s3c-rustfs-0930210446-lock --key c17/locked.txt --query ObjectLockMode --output text
