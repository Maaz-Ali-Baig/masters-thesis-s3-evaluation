$ aws --endpoint-url http://localhost:9000 s3api get-object-lock-configuration --bucket s3c-rustfs-0930210446-lock --query ObjectLockConfiguration.ObjectLockEnabled --output text
