$ aws --endpoint-url http://localhost:9000 s3api copy-object --bucket s3c-rustfs-0930210446-main --key c05/copy.bin --copy-source s3c-rustfs-0930210446-main/fixture/rand1m.bin
