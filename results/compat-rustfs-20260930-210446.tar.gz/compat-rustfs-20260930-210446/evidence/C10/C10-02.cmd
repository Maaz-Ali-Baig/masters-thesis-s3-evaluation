$ aws --endpoint-url http://localhost:9000 s3api put-bucket-versioning --bucket s3c-rustfs-0930210446-ver --versioning-configuration Status=Enabled
