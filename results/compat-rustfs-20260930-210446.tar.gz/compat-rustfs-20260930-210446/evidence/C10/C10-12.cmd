$ aws --endpoint-url http://localhost:9000 s3api delete-object --bucket s3c-rustfs-0930210446-ver --key c10/v.txt --version-id 63b1d9a1-b706-4d5a-b6d2-a0d5273bc300
