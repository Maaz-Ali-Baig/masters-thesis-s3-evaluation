$ aws --endpoint-url http://localhost:9000 s3api list-object-versions --bucket s3c-rustfs-0930210446-ver --prefix c10/v.txt --query length(Versions) --output text
