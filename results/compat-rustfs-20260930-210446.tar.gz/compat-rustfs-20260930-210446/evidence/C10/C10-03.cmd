$ aws --endpoint-url http://localhost:9000 s3api get-bucket-versioning --bucket s3c-rustfs-0930210446-ver --query Status --output text
