$ aws --endpoint-url http://localhost:9000 s3api delete-object --bucket s3c-rustfs-0930210446-ver --key c10/v.txt --query DeleteMarker --output text
