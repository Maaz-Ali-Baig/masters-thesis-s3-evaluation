$ aws --endpoint-url http://localhost:9000 s3api head-bucket --bucket s3c-rustfs-0930210446-c01
