$ aws --endpoint-url http://localhost:9000 s3api list-buckets --query Buckets[].Name --output text
