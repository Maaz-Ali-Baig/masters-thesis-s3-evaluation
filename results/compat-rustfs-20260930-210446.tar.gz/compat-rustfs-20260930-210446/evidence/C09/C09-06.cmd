$ aws --endpoint-url http://localhost:9000 s3api delete-object-tagging --bucket s3c-rustfs-0930210446-main --key c09/tag.txt
