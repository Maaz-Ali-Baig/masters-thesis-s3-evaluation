$ aws --endpoint-url http://localhost:9000 s3api get-object-tagging --bucket s3c-rustfs-0930210446-main --key c09/tag2.txt --query length(TagSet) --output text
