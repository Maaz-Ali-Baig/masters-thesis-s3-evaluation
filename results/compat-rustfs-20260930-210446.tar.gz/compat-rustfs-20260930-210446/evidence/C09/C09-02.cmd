$ aws --endpoint-url http://localhost:9000 s3api put-object-tagging --bucket s3c-rustfs-0930210446-main --key c09/tag.txt --tagging {"TagSet":[{"Key":"env","Value":"test"},{"Key":"k2","Value":"v2"}]}
