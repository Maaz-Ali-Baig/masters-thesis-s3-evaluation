$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:9000/s3c-rustfs-0930210446-main/fixture/rand1m.bin
