$ aws --endpoint-url http://localhost:9000 s3api create-bucket --bucket Bad_Name_s3c-rustfs-0930210446
