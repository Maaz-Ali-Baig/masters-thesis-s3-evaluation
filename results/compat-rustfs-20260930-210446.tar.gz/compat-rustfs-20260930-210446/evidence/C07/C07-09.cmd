$ aws --endpoint-url http://localhost:9000 s3api list-objects-v2 --bucket s3c-rustfs-0930210446-main --prefix c07/ --no-paginate --query KeyCount --output text
