$ aws --endpoint-url http://localhost:9000 s3api delete-object --bucket s3c-rustfs-0930210446-main --key c07/never-existed.txt
