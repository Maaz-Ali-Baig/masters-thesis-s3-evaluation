$ aws --endpoint-url http://localhost:9000 s3api delete-objects --bucket s3c-rustfs-0930210446-main --delete {"Objects":[{"Key":"c07/b.txt"},{"Key":"c07/c.txt"}],"Quiet":false}
