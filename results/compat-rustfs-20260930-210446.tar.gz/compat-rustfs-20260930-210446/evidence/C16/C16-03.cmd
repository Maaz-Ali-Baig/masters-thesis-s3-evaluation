$ aws --endpoint-url http://localhost:9000 s3api delete-bucket-lifecycle --bucket s3c-rustfs-0930210446-main
