$ aws --endpoint-url http://localhost:9000 s3api get-bucket-lifecycle-configuration --bucket s3c-rustfs-0930210446-main --query Rules[0].ID --output text
