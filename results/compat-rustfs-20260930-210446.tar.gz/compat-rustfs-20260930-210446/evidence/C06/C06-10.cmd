$ aws --endpoint-url http://localhost:9000 s3api list-objects-v2 --bucket s3c-rustfs-0930210446-main --prefix c06/ --start-after c06/a/2.txt --query length(Contents) --output text
