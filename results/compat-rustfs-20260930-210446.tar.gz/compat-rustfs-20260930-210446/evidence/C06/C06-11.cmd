$ aws --endpoint-url http://localhost:9000 s3api list-objects --bucket s3c-rustfs-0930210446-main --prefix c06/ --query length(Contents) --output text
