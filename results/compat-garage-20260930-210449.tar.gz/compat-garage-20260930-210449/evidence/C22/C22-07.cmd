$ aws --endpoint-url http://localhost:3900 s3api list-objects-v2 --bucket s3c-garage-0930210449-c22 --query Contents[].Key --output text
