$ aws --endpoint-url http://localhost:3900 s3api create-bucket --bucket Bad_Name_s3c-garage-0930210449
