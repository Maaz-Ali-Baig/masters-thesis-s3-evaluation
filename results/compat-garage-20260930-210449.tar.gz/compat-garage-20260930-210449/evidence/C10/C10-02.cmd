$ aws --endpoint-url http://localhost:3900 s3api put-bucket-versioning --bucket s3c-garage-0930210449-ver --versioning-configuration Status=Enabled
