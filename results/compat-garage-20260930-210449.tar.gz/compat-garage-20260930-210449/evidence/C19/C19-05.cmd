$ aws --endpoint-url http://localhost:3900 s3api put-object-acl --bucket s3c-garage-0930210449-main --key c19/acl.txt --acl public-read
