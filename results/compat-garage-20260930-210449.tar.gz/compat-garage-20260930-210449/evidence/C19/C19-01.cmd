$ aws --endpoint-url http://localhost:3900 s3api get-bucket-acl --bucket s3c-garage-0930210449-main --query length(Grants) --output text
