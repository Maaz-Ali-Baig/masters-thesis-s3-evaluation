$ aws --endpoint-url http://localhost:3900 s3api head-object --bucket s3c-garage-0930210449-main --key fixture/rand1m.bin --query ETag --output text
