$ aws --endpoint-url http://localhost:3900 s3api create-multipart-upload --bucket s3c-garage-0930210449-main --key c08/small-parts.bin --query UploadId --output text
