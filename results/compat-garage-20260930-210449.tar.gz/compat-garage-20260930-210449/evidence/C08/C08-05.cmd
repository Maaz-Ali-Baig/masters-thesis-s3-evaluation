$ aws --endpoint-url http://localhost:3900 s3api list-multipart-uploads --bucket s3c-garage-0930210449-main --query Uploads[].UploadId --output text
