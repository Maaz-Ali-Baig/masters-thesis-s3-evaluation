$ curl -s -o /dev/null -w %{http_code} --max-time 20 http://localhost:3900/s3c-garage-0930210449-main/c14/pub.txt
