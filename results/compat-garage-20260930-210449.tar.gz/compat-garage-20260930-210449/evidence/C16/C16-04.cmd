$ aws --endpoint-url http://localhost:3900 s3api get-bucket-lifecycle-configuration --bucket s3c-garage-0930210449-main
