$ aws --endpoint-url http://localhost:3900 s3 presign s3://s3c-garage-0930210449-main/c13/p.txt --expires-in 60
