$ aws --endpoint-url http://localhost:3900 s3api list-buckets --query Buckets[].Name --output text
