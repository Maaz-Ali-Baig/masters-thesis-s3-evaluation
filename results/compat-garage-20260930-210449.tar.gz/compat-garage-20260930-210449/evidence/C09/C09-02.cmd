$ aws --endpoint-url http://localhost:3900 s3api put-object-tagging --bucket s3c-garage-0930210449-main --key c09/tag.txt --tagging {"TagSet":[{"Key":"env","Value":"test"},{"Key":"k2","Value":"v2"}]}
