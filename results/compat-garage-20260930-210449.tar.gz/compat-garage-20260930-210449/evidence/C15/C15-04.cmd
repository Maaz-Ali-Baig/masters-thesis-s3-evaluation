$ curl -s -D - -o /dev/null --max-time 20 -X OPTIONS -H Origin: https://evil.example -H Access-Control-Request-Method: GET http://localhost:3900/s3c-garage-0930210449-main/fixture/rand1m.bin
