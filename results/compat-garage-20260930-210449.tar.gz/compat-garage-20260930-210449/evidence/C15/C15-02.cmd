$ aws --endpoint-url http://localhost:3900 s3api get-bucket-cors --bucket s3c-garage-0930210449-main --query CORSRules[0].AllowedOrigins[0] --output text
