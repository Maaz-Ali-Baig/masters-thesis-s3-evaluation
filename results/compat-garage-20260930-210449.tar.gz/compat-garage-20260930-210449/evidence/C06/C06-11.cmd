$ aws --endpoint-url http://localhost:3900 s3api list-objects --bucket s3c-garage-0930210449-main --prefix c06/ --query length(Contents) --output text
