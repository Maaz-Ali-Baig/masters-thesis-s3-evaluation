$ aws --endpoint-url http://localhost:3900 s3api list-objects-v2 --bucket s3c-garage-0930210449-main --prefix c06/ --start-after c06/a/2.txt --query length(Contents) --output text
