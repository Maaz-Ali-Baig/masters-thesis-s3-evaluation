$ aws --endpoint-url http://localhost:3900 s3api delete-object --bucket s3c-garage-0930210449-main --key c07/never-existed.txt
