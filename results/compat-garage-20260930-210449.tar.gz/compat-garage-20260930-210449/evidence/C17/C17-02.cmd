$ aws --endpoint-url http://localhost:3900 s3api get-object-lock-configuration --bucket s3c-garage-0930210449-lock --query ObjectLockConfiguration.ObjectLockEnabled --output text
