$ aws --endpoint-url http://localhost:3900 s3api create-bucket --bucket s3c-garage-0930210449-lock --object-lock-enabled-for-bucket
