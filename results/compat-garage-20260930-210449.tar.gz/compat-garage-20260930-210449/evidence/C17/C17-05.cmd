$ aws --endpoint-url http://localhost:3900 s3api delete-object --bucket s3c-garage-0930210449-lock --key c17/locked.txt --version-id d6ace208026e39c7616c0ee3e0bf244321fa218dc8466c93b6153a8dff27dad9
