$ aws --endpoint-url http://localhost:3900 s3api copy-object --bucket s3c-garage-0930210449-main --key c05/copy.bin --copy-source s3c-garage-0930210449-main/fixture/rand1m.bin
